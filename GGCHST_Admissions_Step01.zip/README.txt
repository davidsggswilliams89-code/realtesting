GGCHST Admissions Management — Step 01

Files:
- admissions.html

This is Step 01 of the Admissions Management module.
It uses the GGCHST Firebase project configuration supplied for the SMS.

Firestore collection:
- admissions
- students (used only when an approved applicant is converted)

Implemented:
- Admissions dashboard statistics
- Application CRUD
- Search
- Status/payment filters
- Pending/Screening/Approved/Rejected states
- Payment state
- Basic applicant details
- Approved applicant -> student conversion
- GGCHST green theme
- Link back to admin.html

Next admissions steps:
2. Applicant-facing application portal/account
3. Programme selection from Firestore programmes
4. Document upload/storage and admission_documents
5. Application fee/payment verification
6. Screening workflow
7. Admission decision controls
8. Admission letter generation
9. Student conversion hardening and student-number generation
10. Admission reports/notifications

Important:
This page is a client-side admin UI. Production deployment must enforce Firebase Authentication,
role-based access, Firestore Security Rules, and controlled document/payment operations. Do not rely
on hiding buttons for security.
